<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AutoUpdateDialog</name>
    <message>
        <location filename="autoupdatedialog.ui" line="14"/>
        <source>Xiasl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.ui" line="20"/>
        <source>Close and start upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.ui" line="34"/>
        <source>The upgrade will start automatically after closing, 
 please turn it on again later.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="66"/>
        <source>Download Progress</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSystemWatcher</name>
    <message>
        <location filename="filesystemwatcher.cpp" line="134"/>
        <source>The file has been modified by another program. Do you want to reload?</source>
        <oldsource>The content of the file has been updated. Reload it?</oldsource>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="507"/>
        <location filename="mainwindow.ui" line="520"/>
        <location filename="mainwindow.ui" line="1387"/>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="533"/>
        <location filename="mainwindow.ui" line="1392"/>
        <source>Replace &amp;&amp; Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="678"/>
        <source>Go to previous error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="634"/>
        <source>Go to the next error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="183"/>
        <location filename="mainwindow.ui" line="767"/>
        <location filename="mainwindow.ui" line="1446"/>
        <location filename="mainwindow.cpp" line="4202"/>
        <location filename="mainwindow.cpp" line="5912"/>
        <location filename="mainwindow.cpp" line="5978"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="141"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="780"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="979"/>
        <location filename="mainwindow.cpp" line="375"/>
        <location filename="mainwindow.cpp" line="4001"/>
        <location filename="mainwindow.cpp" line="4801"/>
        <source>BasicInfo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1005"/>
        <location filename="mainwindow.cpp" line="365"/>
        <location filename="mainwindow.cpp" line="1092"/>
        <location filename="mainwindow.cpp" line="1127"/>
        <location filename="mainwindow.cpp" line="4003"/>
        <location filename="mainwindow.cpp" line="4784"/>
        <source>Errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1031"/>
        <location filename="mainwindow.cpp" line="367"/>
        <location filename="mainwindow.cpp" line="1095"/>
        <location filename="mainwindow.cpp" line="1128"/>
        <location filename="mainwindow.cpp" line="4005"/>
        <location filename="mainwindow.cpp" line="4789"/>
        <source>Warnings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1057"/>
        <location filename="mainwindow.cpp" line="369"/>
        <location filename="mainwindow.cpp" line="1098"/>
        <location filename="mainwindow.cpp" line="1129"/>
        <location filename="mainwindow.cpp" line="4007"/>
        <location filename="mainwindow.cpp" line="4794"/>
        <source>Remarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1100"/>
        <source>Optimizations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1142"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1198"/>
        <source>Select Mirror Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1317"/>
        <source>Generate ACPI Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1356"/>
        <source>Previous Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1361"/>
        <source>Next Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1366"/>
        <source>Refresh Tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1371"/>
        <source>Find Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1374"/>
        <source>Ctrl+8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1379"/>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1382"/>
        <source>Ctrl+9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1400"/>
        <source>Information Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1411"/>
        <source>Members List Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1470"/>
        <source>Open Directory of  Current File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1499"/>
        <source>Close Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1552"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1570"/>
        <source>Automatic Line Feeds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1183"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1194"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1229"/>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4108"/>
        <source>Generate ACPI tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1436"/>
        <source>Update Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1465"/>
        <source>Minimap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1302"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1083"/>
        <location filename="mainwindow.cpp" line="370"/>
        <location filename="mainwindow.cpp" line="1100"/>
        <location filename="mainwindow.cpp" line="4009"/>
        <location filename="mainwindow.cpp" line="4797"/>
        <source>Scribble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="718"/>
        <location filename="mainwindow.ui" line="1307"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="656"/>
        <location filename="mainwindow.ui" line="1322"/>
        <source>Compile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1426"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="735"/>
        <location filename="mainwindow.ui" line="1327"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="568"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="581"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="594"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="7327"/>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="212"/>
        <source>Case sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="215"/>
        <source>Aa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="681"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="637"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="546"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="770"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="738"/>
        <source>N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="721"/>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="728"/>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="659"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="745"/>
        <source>Mini Map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="123"/>
        <location filename="mainwindow.cpp" line="7143"/>
        <location filename="mainwindow.cpp" line="7202"/>
        <location filename="mainwindow.cpp" line="7332"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="244"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="257"/>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="270"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="296"/>
        <source>Search Scope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="304"/>
        <source>In Current File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="309"/>
        <source>In All Open Files</source>
        <oldsource>In Open Files</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="314"/>
        <source>In Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="335"/>
        <source>Include Subfolders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="405"/>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="421"/>
        <location filename="mainwindow.cpp" line="7285"/>
        <source>Set Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="364"/>
        <source>Expand / Collapse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="367"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="432"/>
        <source>0    0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="478"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="443"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="748"/>
        <source>Map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="802"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="777"/>
        <location filename="mainwindow.ui" line="825"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1416"/>
        <location filename="mainwindow.cpp" line="5677"/>
        <source>DSDT + SSDT Decompile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1421"/>
        <source>iASL Usage</source>
        <oldsource>iasl Usage</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1431"/>
        <source>ACPICA Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1441"/>
        <source>Replace All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1449"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1454"/>
        <location filename="mainwindow.cpp" line="4197"/>
        <source>Clear search history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1481"/>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1486"/>
        <source>GBK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1491"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1494"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1502"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1507"/>
        <source>Download Upgrade Packages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1515"/>
        <source>https://github.com/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1523"/>
        <source>https://ghproxy.com/https://github.com/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1531"/>
        <source>https://download.fastgit.org/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1539"/>
        <source>https://gh.api.99988866.xyz/https://github.com/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1547"/>
        <source>https://gh.xiu2.xyz/https://github.com/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1557"/>
        <source>Reporting Issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1562"/>
        <source>Latest Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1573"/>
        <source>Ctrl+Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1578"/>
        <source>Set Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1581"/>
        <source>Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1586"/>
        <location filename="mainwindow.ui" line="1594"/>
        <source>Bookmarks List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1597"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1312"/>
        <source>Save as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1158"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1338"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1346"/>
        <source>WrapWord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="1351"/>
        <source>Kextstat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="321"/>
        <source>Last modified: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="526"/>
        <location filename="mainwindow.cpp" line="694"/>
        <location filename="mainwindow.cpp" line="776"/>
        <location filename="mainwindow.cpp" line="4045"/>
        <location filename="mainwindow.cpp" line="4973"/>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="527"/>
        <location filename="mainwindow.cpp" line="4046"/>
        <source>Cannot read file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="597"/>
        <source>File loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <location filename="mainwindow.cpp" line="4964"/>
        <location filename="mainwindow.cpp" line="5159"/>
        <location filename="mainwindow.cpp" line="5174"/>
        <location filename="mainwindow.cpp" line="5186"/>
        <location filename="mainwindow.cpp" line="5548"/>
        <location filename="mainwindow.cpp" line="5619"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="695"/>
        <location filename="mainwindow.cpp" line="4974"/>
        <source>The document has been modified.
Do you want to save your changes?

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="765"/>
        <location filename="mainwindow.cpp" line="5036"/>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="770"/>
        <source>Cannot open file %1 for writing:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="798"/>
        <source>File saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="996"/>
        <source>Compiling...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1048"/>
        <source>Empty search field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1049"/>
        <source>The search field is empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1137"/>
        <location filename="mainwindow.cpp" line="1239"/>
        <source>Compiled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1166"/>
        <location filename="mainwindow.cpp" line="1253"/>
        <source>Compilation successful.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1168"/>
        <location filename="mainwindow.cpp" line="1255"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1282"/>
        <location filename="mainwindow.cpp" line="2295"/>
        <source>Row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1283"/>
        <location filename="mainwindow.cpp" line="2296"/>
        <source>Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2213"/>
        <source>Refresh completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2274"/>
        <source>Refreshing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4037"/>
        <source>This is a scribble board to temporarily record something, and the content will be saved and loaded automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4104"/>
        <source>Current SSDT List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4180"/>
        <source>TAB List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4068"/>
        <source>Clear List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4089"/>
        <source>Open Recent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4151"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4234"/>
        <source>ctrl+n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4237"/>
        <source>ctrl+o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4241"/>
        <source>ctrl+s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4245"/>
        <source>ctrl+shift+s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4249"/>
        <source>ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4257"/>
        <source>ctrl+g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4266"/>
        <source>ctrl+m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4271"/>
        <source>ctrl+r</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4283"/>
        <source>ctrl+k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4288"/>
        <source>ctrl+j</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4296"/>
        <source>ctrl+alt+e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4301"/>
        <source>ctrl+e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4311"/>
        <source>ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4315"/>
        <source>ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4319"/>
        <source>ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4659"/>
        <source>Expand all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4664"/>
        <source>Collapse all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="4687"/>
        <source>Open directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5792"/>
        <source>You are currently using the latest version!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5958"/>
        <location filename="mainwindow.cpp" line="5963"/>
        <source>Clear history entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="6605"/>
        <source>The file has been modified by another program. Do you want to reload?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="7143"/>
        <location filename="mainwindow.cpp" line="7203"/>
        <location filename="mainwindow.cpp" line="7333"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="7144"/>
        <location filename="mainwindow.cpp" line="7201"/>
        <location filename="mainwindow.cpp" line="7331"/>
        <source>Matches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5762"/>
        <source>Network error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5778"/>
        <source>New version detected!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5779"/>
        <source>Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5780"/>
        <source>Published at: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5781"/>
        <source>Release Notes: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5782"/>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5783"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="35"/>
        <location filename="mainwindow.ui" line="53"/>
        <location filename="mainwindow.cpp" line="4647"/>
        <source>Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="5098"/>
        <source> Layer </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Methods</name>
    <message>
        <location filename="methods.cpp" line="227"/>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="methods.cpp" line="228"/>
        <source>Cannot read file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QInstaller</name>
    <message>
        <location filename="autoupdatedialog.cpp" line="267"/>
        <source>bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="268"/>
        <source>KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="269"/>
        <source>MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="270"/>
        <source>GiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="271"/>
        <source>TiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="272"/>
        <source>PiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="273"/>
        <source>EiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="274"/>
        <source>ZiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="autoupdatedialog.cpp" line="275"/>
        <source>YiB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecentFiles</name>
    <message>
        <location filename="recentfiles.cpp" line="28"/>
        <source>Open Recent...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgDecompile</name>
    <message>
        <location filename="dlgdecompile.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.ui" line="27"/>
        <location filename="dlgdecompile.ui" line="71"/>
        <source>Decompile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.ui" line="33"/>
        <source>Choose DSDT or SSDT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.ui" line="40"/>
        <source>DSDT or SSDT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.ui" line="50"/>
        <source>Add SSDT or DSDT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.ui" line="57"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.ui" line="64"/>
        <source>Clear list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.ui" line="79"/>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgdecompile.cpp" line="25"/>
        <location filename="dlgdecompile.cpp" line="36"/>
        <source>Select files to open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dlgPreferences</name>
    <message>
        <location filename="dlgpreferences.ui" line="14"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="20"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="26"/>
        <source>Select Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="36"/>
        <source>Compile Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="42"/>
        <source>Decompile all AML files in the directory where the opened file is located</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="45"/>
        <source>Batch decompilation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="52"/>
        <source>Compilation options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="62"/>
        <source>Encoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="68"/>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="78"/>
        <source>GBK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="88"/>
        <source>Additional Options</source>
        <oldsource>Additional Settings</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreferences.ui" line="94"/>
        <source>Automatic line feed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>miniDialog</name>
    <message>
        <location filename="minidialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="minidialog.cpp" line="24"/>
        <source>Left click: Position to the current line.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="minidialog.cpp" line="25"/>
        <source>Right click: Copy the current line.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
