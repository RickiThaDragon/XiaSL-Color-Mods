class OSXHideTitleBar
{
public:
    static void HideTitleBar(long winid);

};
