[简体中文](https://github.com/ic005k/QtiASL/blob/master/README-cn.md) | [English](https://github.com/ic005k/QtiASL/blob/master/README.md)
## Xiasl--开源跨平台的DSDT&SSDT集成开发环境

Xiasl是一个现代的、轻量的、功能丰富的跨平台的DSDT集成开发环境。


### Credits

[ACPI](https://acpica.org/source) &nbsp; &nbsp; &nbsp; &nbsp;
[QSci](https://riverbankcomputing.com/software/qscintilla/download) &nbsp; &nbsp; &nbsp; &nbsp;
[patchmatic](https://github.com/RehabMan/OS-X-MaciASL-patchmatic) &nbsp; &nbsp; &nbsp; &nbsp;

---

API: https://api.github.com/repos/ic005k/Xiasl/releases/latest
